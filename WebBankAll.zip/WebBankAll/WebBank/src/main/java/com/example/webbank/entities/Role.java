package com.example.webbank.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

//@Entity
//@Table(name = "USER_ROLES")
public class Role {
	
//	@Id
//	@SequenceGenerator(name = "roles_id_seq", sequenceName = "roles_id_seq", allocationSize = 1 )
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "roles_id_seq")
//	@Column(name = "id", unique = true, nullable = false )
	private long id;

//	@ManyToOne
//	@JoinColumn(name = "user_id")
	private User user;

//	@Column(name = "user_role", length = 60)
	private String role;


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}


	
}
