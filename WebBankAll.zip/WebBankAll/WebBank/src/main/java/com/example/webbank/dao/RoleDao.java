package com.example.webbank.dao;

import java.util.List;

import com.example.webbank.entities.Role;
import com.example.webbank.entities.User;

public interface RoleDao {

	List<Role> getRolesForUser(User user);
	
}
