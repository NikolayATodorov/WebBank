package com.example.webbank.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.webbank.entities.Role;
import com.example.webbank.entities.User;

@Repository
public class RoleDaoImpl extends AbstractDAO implements RoleDao {

	@Override
	public List<Role> getRolesForUser(User user) {
		List<Role> roles = new ArrayList<Role>();
		
		String sql = "SELECT * FROM user_roles WHERE user_id=?";

	try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setLong(1, user.getId());			
			
			ResultSet result = stmt.executeQuery();

			while (result.next()) {
				Role role = new Role();

				role.setId(result.getLong("id"));
				role.setUser(user);
				role.setRole(result.getString("user_role"));
				roles.add(role);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return roles;
	}
	
}
