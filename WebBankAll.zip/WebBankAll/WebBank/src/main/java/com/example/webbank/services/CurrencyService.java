package com.example.webbank.services;

import java.util.List;

import com.example.webbank.entities.Currency;

public interface CurrencyService {

	Currency getCurrencyById(long id);
	List<Currency> getAllCurrencies();
	
}
