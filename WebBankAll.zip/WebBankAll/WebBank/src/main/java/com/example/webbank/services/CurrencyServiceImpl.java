package com.example.webbank.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.webbank.dao.CurrencyDao;
import com.example.webbank.entities.Currency;

@Service
public class CurrencyServiceImpl implements CurrencyService {

	@Autowired
	CurrencyDao currencyDao;
	
	@Override
	public Currency getCurrencyById(long id) {
		return currencyDao.getCurrencyById(id);
	}

	@Override
	public List<Currency> getAllCurrencies() {
		return currencyDao.getAllCurrencies();
	}

}
