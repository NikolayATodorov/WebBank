package com.example.webbank.constants;

public class WebbankConstants {
	
	
	public static final String ACTION = "action";

	public static final String ACTION_VIEW = "view";
	public static final String ACTION_EDIT = "edit";
	public static final String ACTION_ADD = "add";

	
	public static final String ROLE_EMPLOYEE = "ROLE_EMPLOYEE";
	public static final String ROLE_MANAGER = "ROLE_MANAGER";
	public static final String ROLE_EXTERNAL = "ROLE_EXTERNAL";


}
