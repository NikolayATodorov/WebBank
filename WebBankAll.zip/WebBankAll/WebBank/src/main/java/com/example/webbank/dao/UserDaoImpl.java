package com.example.webbank.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.webbank.entities.Role;
import com.example.webbank.entities.User;

@Repository
public class UserDaoImpl extends AbstractDAO implements UserDao {

	@Autowired
	RoleDao roleDao;
	

	public List<User> getAllUsers() {
		List<User> users = new ArrayList<User>();

		try (Statement stmt = getConnection().createStatement();) {

			String sql = "SELECT * FROM bank_users";

			ResultSet result = stmt.executeQuery(sql);

			while (result.next()) {
				User user = new User();

				user.setId(result.getLong("id"));
				user.setPid(result.getString("pid"));
				user.setFirstName(result.getString("firstname"));
				user.setLastName(result.getString("lastname"));
				user.setUsername(result.getString("username"));
				user.setPassword(result.getString("password"));

				users.add(user);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return users;
	}

	@Override
	public User getUserByUsername(String username) {
		User user = new User();

		String sql = "SELECT * FROM bank_users where username=?";

		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {

			stmt.setString(1, username);
			ResultSet result = stmt.executeQuery();
			result.next();
			
			user.setId(result.getLong("id"));
			user.setPid(result.getString("pid"));
			user.setFirstName(result.getString("firstname"));
			user.setLastName(result.getString("lastname"));
			user.setUsername(result.getString("username"));
			user.setPassword(result.getString("password"));
			List<Role> roles = roleDao.getRolesForUser(user);
			user.setRoles(roles);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return user;
	}
	
	@Override
	public User getUserById(long id) {
		User user = new User();

		String sql = "SELECT * FROM bank_users where id=?";

		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {

			stmt.setLong(1, id);

			ResultSet result = stmt.executeQuery();
			result.next();
			user.setId(result.getLong("id"));
			user.setPid(result.getString("pid"));
			user.setFirstName(result.getString("firstname"));
			user.setLastName(result.getString("lastname"));
			user.setUsername(result.getString("username"));
			user.setPassword(result.getString("password"));
			List<Role> roles = roleDao.getRolesForUser(user);
			user.setRoles(roles);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return user;
	}
	
	@Override
	public User getUserByPid(String pid) {
		// TODO not necessary yet
		return null;
	}

	@Override
	public boolean deleteUser(long id) {
		String sql = "DELETE FROM bank_users WHERE id=?";
		
		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setLong(1, id);
			stmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean addUser(User user) {
		String sql = "INSERT INTO bank_users (pid, firstname, lastname, username, password) VALUES (?, ?, ?, ?, ?)";
		
		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setString(1, user.getPid());;
			stmt.setString(2, user.getFirstName());
			stmt.setString(3, user.getLastName());
			stmt.setString(4, user.getUsername());
			stmt.setString(5, user.getPassword());

			stmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean editUser(User user) {
		String sql = "UPDATE bank_users SET pid=?, firstname=?, lastname=?, username=?, password=? WHERE id=?";
		
		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {

			stmt.setString(1, user.getPid());;
			stmt.setString(2, user.getFirstName());
			stmt.setString(3, user.getLastName());
			stmt.setString(4, user.getUsername());
			stmt.setString(5, user.getPassword());
			stmt.setLong(6, user.getId());

			stmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	public boolean editUserDummy() {
		String sql = "UPDATE bank_users SET pid='anpid', firstname='an', lastname='an', username='an', password='an' WHERE id=107";

		try (Statement stmt = getConnection().createStatement();) {

			stmt.executeQuery(sql);

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

}
