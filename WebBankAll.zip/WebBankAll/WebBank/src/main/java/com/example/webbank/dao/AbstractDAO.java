package com.example.webbank.dao;

import java.sql.Connection;

public abstract class AbstractDAO {
	private final Connection connection = DBConnection.getDBConnection();

	public Connection getConnection() {
		return connection;
	}
	
}
