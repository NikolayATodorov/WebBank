package com.example.webbank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	public static final String URL = "jdbc:oracle:thin:@localhost:49161:XE";
	public static final String USERNAME = "Bank";
	public static final String PASSWORD = "Bank";

	
	private static DBConnection instance = null;

	private Connection connection;

	private DBConnection() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static DBConnection getInstance() {
		if (instance == null) {
			synchronized (DBConnection.class) {
				if (instance == null) {
					instance = new DBConnection();
				}
			}
		}
		return instance;
	}

	public Connection getConnection() {
		return connection;
	}
	
	public static Connection getDBConnection() {
		return getInstance().getConnection();
	}

}
