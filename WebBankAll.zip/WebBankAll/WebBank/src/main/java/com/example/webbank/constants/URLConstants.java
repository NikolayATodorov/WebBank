package com.example.webbank.constants;

public class URLConstants {
	
	public static final String LOGIN = "/login";
	public static final String LOGOUT = "/logout";
	public static final String HOME = "/home";

	
	public static final String SAVE_USER = "/saveUser";
	public static final String ADD_USER = "/addUser";
	public static final String EDIT_USER = "/editUser";
	public static final String DELETE_USER = "/deleteUser";
	public static final String LOAD_USER = "/loadUser";
	public static final String LOAD_USERS = "/loadUsers";

	public static final String SAVE_ACCOUNT = "/saveAccount";
	public static final String ADD_ACCOUNT = "/addAccount";
	public static final String EDIT_ACCOUNT = "/editAccount";
	public static final String DELETE_ACCOUNT = "/deleteAccount";
	public static final String LOAD_ACCOUNT = "/loadAccount";
	public static final String LOAD_ACCOUNTS = "/loadAccounts";
	
}
