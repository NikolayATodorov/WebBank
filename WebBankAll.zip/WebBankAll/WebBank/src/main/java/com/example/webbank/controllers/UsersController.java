package com.example.webbank.controllers;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.webbank.constants.URLConstants;
import com.example.webbank.constants.WebbankConstants;
import com.example.webbank.dao.UserDao;
import com.example.webbank.entities.User;
import com.example.webbank.services.AccountService;
import com.example.webbank.services.UserService;
import com.example.webbank.utils.UserUtils;


@Controller
public class UsersController {

	@Autowired
	UserDao userDao;
	
	@Autowired
	UserService userService;
	@Autowired
	AccountService accountService;
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.LOAD_USERS, method = RequestMethod.GET)
	public String loadUsers(Model model) {

		List<User> usersList = userService.getAllUsers();
		model.addAttribute("users", usersList);

		return "listUsers";
	}
	
	@RequestMapping(value = URLConstants.LOAD_USER, method = RequestMethod.GET)
	public String loadUserById(Model model, HttpServletRequest request) {
		User currentUser = UserUtils.getUser();
		if (currentUser == null) {
			return "redirect:login";
		}
		long userId = Long.parseLong(request.getParameter("userId"));
		
		Collection<GrantedAuthority> userAuthorities = currentUser.getAuthorities();
		User user = null;
		if (!userAuthorities.contains(new SimpleGrantedAuthority(WebbankConstants.ROLE_EMPLOYEE)) &&
				!userAuthorities.contains(new SimpleGrantedAuthority(WebbankConstants.ROLE_MANAGER))) {
			
			user = userService.getUserByUsername(currentUser.getUsername());

		} else {
			user = userService.getUserById(userId);
		}
		
		model.addAttribute("user", user);

		return "userDetails";
	}
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.ADD_USER, method = RequestMethod.GET)
	public String addUser(Model model) {
		User currentUser = userService.getUserByUsername(UserUtils.getUser().getUsername());
		
		User user = new User();
		model.addAttribute("user", user);
		model.addAttribute("currentUser", currentUser);

		model.addAttribute(WebbankConstants.ACTION, "addUser");

		return "addUserForm";
	}
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.SAVE_USER, method = RequestMethod.POST)
	public String saveUser(Model model, @ModelAttribute User user, HttpServletRequest request) {
		String action = request.getParameter(WebbankConstants.ACTION);
		
		if ("addUser".equals(action)) {
			userService.addUser(user);
		} else {
			userService.editUser(user);
		}
		
		return "redirect:loadUsers";
	}
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.EDIT_USER, method = RequestMethod.GET)
	public String editUser(Model model, HttpServletRequest request) {
		User currentUser = userService.getUserByUsername(UserUtils.getUser().getUsername());
		long userId = Long.parseLong(request.getParameter("userId"));

		User user = userService.getUserById(userId);
		
		model.addAttribute("user", user);
		model.addAttribute("currentUser", currentUser);

		model.addAttribute(WebbankConstants.ACTION, "editUser");
		return "addUserForm";
	}
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.DELETE_USER, method = RequestMethod.POST)
	public String deleteUser(Model model, @ModelAttribute User user, HttpServletRequest request) {
		long userId = Long.parseLong(request.getParameter("userId"));
		userService.deleteUser(userId);
		
		return "redirect:loadUsers";
	}

}
