package com.example.webbank.dao;

import java.util.List;

import com.example.webbank.entities.User;

public interface UserDao {

	List<User> getAllUsers();
	User getUserById(long id);

	User getUserByPid(String pid);
	User getUserByUsername(String username);
	boolean addUser(User user);
	boolean deleteUser(long id);
	boolean editUser(User user);
	public boolean editUserDummy();


}
