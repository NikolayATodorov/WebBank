package com.example.webbank.services;

import java.util.List;

import com.example.webbank.entities.Account;

public interface AccountService {
	
	List<Account> getAllAccounts();
	Account getAccountById(long id);
	List<Account> getAllAccountsForUser(long id);
	List<Account> getAllAccountsForUser(String username);
	boolean deleteAccount(long id);
	boolean addAccount(Account account);
	boolean editAccount(Account account);

}
