package com.example.webbank.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.webbank.entities.Account;
import com.example.webbank.entities.Currency;
import com.example.webbank.entities.User;

@Repository
public class AccountDaoImpl extends AbstractDAO implements AccountDao {

	@Autowired
	UserDao userDao;

	@Autowired
	CurrencyDao currencyDao;

	@Override
	public List<Account> getAllAccounts() {
		List<Account> accounts = null;

		String sql = "SELECT * FROM accounts";

		try (Statement stmt = getConnection().createStatement();) {

			ResultSet result = stmt.executeQuery(sql);
			accounts = getAllAccounts(result);

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return accounts;
	}

	@Override
	public Account getAccountById(long id) {
		Account account = null;

		String sql = "SELECT * FROM accounts WHERE id=?";

		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setLong(1, id);
			ResultSet result = stmt.executeQuery();
			result.next();
			
			account = getAccount(result);

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return account;
	}

	@Override
	public List<Account> getAllAccountsForUser(long id) {
		List<Account> accounts = new ArrayList<Account>();

		String sql = "SELECT a.id, a.account_number, a.owner, a.amount, a.currency, a.created_by"
				+ " FROM accounts a, bank_users u WHERE u.id=? and a.owner=u.id";
		
	try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setLong(1, id);
			ResultSet result = stmt.executeQuery();
			accounts = getAllAccounts(result);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return accounts;
	}

	@Override
	public List<Account> getAllAccountsForUser(String username) {
		List<Account> accounts = new ArrayList<Account>();

		String sql = "SELECT a.id, a.account_number, a.owner, a.amount, a.currency, a.created_by"
				+ " FROM accounts a, bank_users u WHERE u.username=? and a.owner=u.id";
		
	try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setString(1, username);
			ResultSet result = stmt.executeQuery();
			accounts = getAllAccounts(result);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return accounts;
	}
	
	private Account getAccount(ResultSet result) {
		Account account = new Account();

		try {
			
			account.setId(result.getLong("id"));
			account.setAccountNumber(result.getString("account_number"));
			User owner = userDao.getUserById(result.getLong("owner"));
			account.setOwner(owner);
			account.setAmount(result.getDouble("amount"));
			Currency currency = currencyDao.getCurrencyById(result.getLong("currency"));
			account.setCurrency(currency);
			User createdBy = userDao.getUserById(result.getLong("created_by"));
			account.setCreatedBy(createdBy);
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		return account;
	}
	
	private List<Account> getAllAccounts(ResultSet result) {
		List<Account> accounts = new ArrayList<Account>();
		
		try {
			
			while (result.next()) {
				Account account = getAccount(result);
				accounts.add(account);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return accounts;
	}

	@Override
	public boolean deleteAccount(long id) {
		String sql = "DELETE FROM accounts WHERE id=?";
		
		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setLong(1, id);
			stmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean addAccount(Account account) {
		String sql = "INSERT INTO accounts (account_number, owner, amount, currency, created_by) VALUES (?, ?, ?, ?, ?)";
		
		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setString(1, account.getAccountNumber());
			stmt.setLong(2, account.getOwner().getId());
			stmt.setDouble(3, account.getAmount());
			stmt.setDouble(4, account.getCurrency().getId());
			stmt.setDouble(5, account.getCreatedBy().getId());

			stmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}

	@Override
	public boolean editAccount(Account account) {
		String sql = "UPDATE accounts SET account_number=?, owner=?, amount=?, currency=?, created_by=? WHERE id=?";
		
		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {

			stmt.setString(1, account.getAccountNumber());
			stmt.setLong(2, account.getOwner().getId());
			stmt.setDouble(3, account.getAmount());
			stmt.setLong(4, account.getCurrency().getId());
			stmt.setLong(5, account.getCreatedBy().getId());
			stmt.setLong(6, account.getId());

			stmt.executeQuery();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
}
