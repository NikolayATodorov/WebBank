package com.example.webbank.controllers;

import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.webbank.constants.URLConstants;
import com.example.webbank.constants.WebbankConstants;
import com.example.webbank.entities.Account;
import com.example.webbank.entities.Currency;
import com.example.webbank.entities.User;
import com.example.webbank.services.AccountService;
import com.example.webbank.services.CurrencyService;
import com.example.webbank.services.UserService;
import com.example.webbank.utils.UserUtils;


@Controller
public class AccountsController {

	@Autowired
	UserService userService;
	@Autowired
	CurrencyService currencyService;
	@Autowired
	AccountService accountService;


	@RequestMapping(value = URLConstants.LOAD_ACCOUNTS, method = RequestMethod.GET)
	public String loadAccounts(Model model, HttpServletRequest request) {
		User currentUser = UserUtils.getUser();
		if (currentUser == null) {
			return "redirect:" + URLConstants.LOGIN;
		}
		
		long ownerId = 0;
		
		Collection<GrantedAuthority> userAuthorities = currentUser.getAuthorities();
		List<Account> accountsList = null;

		if (userAuthorities.contains(new SimpleGrantedAuthority(WebbankConstants.ROLE_EMPLOYEE))
				|| userAuthorities.contains(new SimpleGrantedAuthority(WebbankConstants.ROLE_MANAGER))) {
			// user is authorized to view other accounts than his own
			if (request.getParameter("ownerId") != null) {
//				long ownerId = Long.parseLong(request.getParameter("ownerId"));

				ownerId = Long.parseLong(request.getParameter("ownerId"));
				accountsList = accountService.getAllAccountsForUser(ownerId);
			} else {
				accountsList =	accountService.getAllAccounts();
			}

		} else { // user is NOT authorized to view other accounts than his own

			accountsList =	accountService.getAllAccountsForUser(currentUser.getUsername());
		}
		model.addAttribute("owner", ownerId);

		model.addAttribute("accounts", accountsList);

		return "listAccounts";
	}
	
	@RequestMapping(value = URLConstants.LOAD_ACCOUNT, method = RequestMethod.GET)
	public String loadAccountById(Model model, HttpServletRequest request) {
		long accountId = Long.parseLong(request.getParameter("accountId"));
		Account account = accountService.getAccountById(accountId);
//		String action = request.getParameter(WebbankConstants.ACTION);

		model.addAttribute("account", account);
		
		return "accountDetails";
	}

	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.ADD_ACCOUNT, method = RequestMethod.GET)
	public String addAccount(Model model) {
		Account account = new Account();
		List<Currency> currencyList = currencyService.getAllCurrencies();
		List<User> userList = userService.getAllUsers();
		User currentUser = userService.getUserByUsername(UserUtils.getUser().getUsername());
		
		model.addAttribute("account", account);
		model.addAttribute("currencyList", currencyList);
		model.addAttribute("userList", userList);
		model.addAttribute("currentUser", currentUser);

		model.addAttribute(WebbankConstants.ACTION, "addAccount");

		return "addAccountForm";
	}
	
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.EDIT_ACCOUNT, method = RequestMethod.GET)
	public String editAccount(Model model, HttpServletRequest request) {
		User currentUser = userService.getUserByUsername(UserUtils.getUser().getUsername());
		long accountId = Long.parseLong(request.getParameter("accountId"));
		Account account = accountService.getAccountById(accountId);
		
		List<Currency> currencyList = currencyService.getAllCurrencies();
		List<User> userList = userService.getAllUsers();
		
		model.addAttribute("account", account);
		model.addAttribute("currencyList", currencyList);
		model.addAttribute("userList", userList);
		model.addAttribute("currentUser", currentUser);

		model.addAttribute(WebbankConstants.ACTION, "editAccount");
		return "addAccountForm";
	}
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.DELETE_ACCOUNT, method = RequestMethod.POST)
	public String deleteAccount(Model model, HttpServletRequest request) {
		long accountId = Long.parseLong(request.getParameter("accountId"));
		accountService.deleteAccount(accountId);

		return "redirect:" + URLConstants.LOAD_ACCOUNTS;
	}
	
	@Secured({WebbankConstants.ROLE_EMPLOYEE, WebbankConstants.ROLE_MANAGER})
	@RequestMapping(value = URLConstants.SAVE_ACCOUNT, method = RequestMethod.POST)
	public String saveAccount(Model model, @ModelAttribute Account account, HttpServletRequest request) {
//		accountService.addAccount(account);
		String action = request.getParameter(WebbankConstants.ACTION);

		if ("addAccount".equals(action)) {
			accountService.addAccount(account);
		} else {
			accountService.editAccount(account);
		}
		
		return "redirect:" + URLConstants.LOAD_ACCOUNTS;
	}
	
}
