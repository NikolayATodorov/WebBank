package com.example.webbank.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.webbank.constants.URLConstants;
import com.example.webbank.entities.User;
import com.example.webbank.services.UserService;
import com.example.webbank.utils.UserUtils;

@Controller
public class LoginController {

	@Autowired
	UserService userService;
	
	@RequestMapping(value = URLConstants.LOGIN, method = RequestMethod.GET)
	public String loginPage(Model model) {
		return "login";
	}
	
	@RequestMapping(value = URLConstants.HOME, method = RequestMethod.GET)
	public String homePage(Model model) {
		User user = UserUtils.getUser();
		if(user == null) {
			return "redirect:/login?logout";
		}
		user = userService.getUserByUsername(user.getUsername());
		model.addAttribute("user", user);
		return "home";
	}
	
	@RequestMapping(value = URLConstants.LOGOUT, method = RequestMethod.GET)
	public String logout() {
		return "redirect:/login?logout";
	}
	
}