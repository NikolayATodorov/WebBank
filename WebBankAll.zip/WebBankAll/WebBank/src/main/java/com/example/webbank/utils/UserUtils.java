package com.example.webbank.utils;

import org.springframework.security.core.context.SecurityContextHolder;

import com.example.webbank.entities.User;

public class UserUtils {

	private UserUtils() {
	}

	public static User getUser() {
		Object principal;

		try {
			principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		} catch (NullPointerException e) {
			return null;
		}

		if (principal == null || !(principal instanceof User)) {
			return null;
		}

		// maybe it is a good idea to populate all the attributes of the (User) principal before return
		// because at this point only username, password and authorities are populated the rest is null
		return (User) principal;
	}
}