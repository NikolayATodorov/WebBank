package com.example.webbank.security;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.webbank.dao.UserDao;
import com.example.webbank.entities.Role;
import com.example.webbank.entities.User;

public class UserDetailsServiceImpl implements UserDetailsService {

	private static final String ADMIN_USER_NAME = "admin";
	
	@Autowired
	private UserDao userDao;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		List<Role> roles = new ArrayList<>();
		List<GrantedAuthority> authorities = new ArrayList<>();
		
		User user = userDao.getUserByUsername(username);
		if(user != null){
			roles = user.getRoles();
			for(Role role : roles){
				if(role.getRole().equals("ROLE_MANAGER")){
					authorities.add(new SimpleGrantedAuthority("ROLE_MANAGER"));
				} else if(role.getRole().equals("ROLE_EMPLOYEE")){
					authorities.add(new SimpleGrantedAuthority("ROLE_EMPLOYEE"));
				} else if(role.getRole().equals("ROLE_EXTERNAL")){
					authorities.add(new SimpleGrantedAuthority("ROLE_EXTERNAL"));
				} 
			}
		} else {
			throw new UsernameNotFoundException("Username " + username + " not found!");
		}
		
		String dbPassword = user.getPassword();
		return new User(username, dbPassword, authorities);
	}
}																												