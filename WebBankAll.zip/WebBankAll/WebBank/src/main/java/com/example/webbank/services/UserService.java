package com.example.webbank.services;

import java.util.List;

import com.example.webbank.entities.User;

public interface UserService {
	
	List<User> getAllUsers();
	User getUserById(long id);
	User getUserByUsername(String username);
	User getUserByPid(String pid);
	boolean addUser(User user);
	boolean deleteUser(long id);
	boolean editUser(User user);

}
