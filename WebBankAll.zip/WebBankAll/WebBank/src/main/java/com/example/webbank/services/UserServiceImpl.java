package com.example.webbank.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.webbank.dao.UserDao;
import com.example.webbank.entities.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao userDao;
	
	@Override
	public List<User> getAllUsers() {
		return userDao.getAllUsers();
	}

	@Override
	public User getUserById(long id) {
		return userDao.getUserById(id);
	}

	@Override
	public User getUserByUsername(String username) {
		return userDao.getUserByUsername(username);
	}
	
	@Override
	public User getUserByPid(String pid) {
//		NOT IMPLEMENTED
		return null;
	}

	@Override
	public boolean addUser(User user) {
		userDao.addUser(user);
		return true;
	}
	
	@Override
	public boolean deleteUser(long id) {
		userDao.deleteUser(id);
		return true;
	}

	@Override
	public boolean editUser(User user) {
		userDao.editUser(user);
		return true;
	}
	

}
