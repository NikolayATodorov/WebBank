package com.example.webbank.dao;

import java.util.List;

import com.example.webbank.entities.Currency;

public interface CurrencyDao {
	
	List<Currency> getAllCurrencies();
	Currency getCurrencyById(long id);

}
