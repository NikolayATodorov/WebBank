package com.example.webbank.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.webbank.entities.Currency;

@Repository
public class CurrencyDaoImpl extends AbstractDAO implements CurrencyDao {

	@Override
	public List<Currency> getAllCurrencies() {
		List<Currency> currencies = new ArrayList<Currency>();

		String sql = "SELECT * FROM currencies";

		try (Statement stmt = getConnection().createStatement();) {
			
			ResultSet result = stmt.executeQuery(sql);

			while (result.next()) {
				Currency currency = new Currency();

				currency.setId(result.getLong("id"));
				currency.setCode(result.getString("code"));
				currency.setName(result.getString("name"));

				currencies.add(currency);
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return currencies;
	}

	@Override
	public Currency getCurrencyById(long id) {
		Currency currency = new Currency();

		String sql = "SELECT * FROM currencies where id=?";

		try (PreparedStatement stmt = getConnection().prepareStatement(sql);) {
			
			stmt.setLong(1, id);

			ResultSet result = stmt.executeQuery();
			result.next();
			
			currency.setId(result.getLong("id"));
			currency.setCode(result.getString("code"));
			currency.setName(result.getString("name"));
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return currency;
	}

}
