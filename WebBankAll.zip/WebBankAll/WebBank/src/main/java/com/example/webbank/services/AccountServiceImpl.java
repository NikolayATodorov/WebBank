package com.example.webbank.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.webbank.dao.AccountDao;
import com.example.webbank.entities.Account;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountDao accountDao;
	
	@Override
	public List<Account> getAllAccounts() {
		return accountDao.getAllAccounts();
	}

	@Override
	public Account getAccountById(long id) {
		return accountDao.getAccountById(id);
	}

	@Override
	public List<Account> getAllAccountsForUser(long id) {
		return accountDao.getAllAccountsForUser(id);
	}

	@Override
	public List<Account> getAllAccountsForUser(String username) {
		return accountDao.getAllAccountsForUser(username);
	}

	@Override
	public boolean deleteAccount(long id) {
		return accountDao.deleteAccount(id);
	}

	@Override
	public boolean addAccount(Account account) {
		return accountDao.addAccount(account);
	}

	@Override
	public boolean editAccount(Account account) {
		return accountDao.editAccount(account);
	}
	
}
